import React from 'react'
import Menu from './Components/Header/Navbar/Menu'
import LandingPage from './LandingPage'
import './App.css'

const App = () => {
  return (
	<div>
		<LandingPage/>
	</div>
  )
}

export default App